// const BROKER = require('./BROKER.js')

const sockets = {}


// const disconnect = event => {
// 	const { socket } = event
// 	delete sockets[ socket.request.session?.uuid ]
// }


// BROKER.subscribe('SOCKET_DISCONNECT', disconnect )

module.exports = sockets
