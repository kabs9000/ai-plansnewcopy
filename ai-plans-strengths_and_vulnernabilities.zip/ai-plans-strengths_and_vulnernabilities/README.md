autonomous interest partner
